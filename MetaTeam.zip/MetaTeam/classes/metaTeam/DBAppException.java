package metaTeam;

@SuppressWarnings("serial")
public class DBAppException extends Throwable{

}
